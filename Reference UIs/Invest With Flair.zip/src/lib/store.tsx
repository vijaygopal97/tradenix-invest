import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";

// Mock data store — drop-in stand-in for the backend API so the redesign is fully interactive.

export type Role = "user" | "admin";
export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  balance: number;
  joined: string;
}
export interface Transaction {
  id: string;
  userId: string;
  createdAt: string;
  type: "recharge" | "withdrawal" | "interest_accrual" | "adjustment";
  amount: number;
  balanceAfter: number;
  note?: string;
}
export interface Recharge {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  createdAt: string;
  status: "pending" | "approved" | "rejected";
  paymentDescription?: string;
  screenshotUrl?: string;
  adminRemarks?: string;
}
export interface BankAccount {
  id: string;
  accountHolderName: string;
  bankName: string;
  accountNumber: string;
  ifscOrSwift: string;
  branch?: string;
}
export interface Withdrawal {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  createdAt: string;
  status: "pending" | "paid" | "rejected";
  bankAccount: BankAccount;
  adminRemarks?: string;
  paymentProofUrl?: string;
}
export interface InterestLog {
  id: string;
  dailyPercent: number;
  effectiveFrom: string;
  changedBy: string;
  note?: string;
}
export interface PlatformBank {
  accountHolderName: string;
  bankName: string;
  accountNumber: string;
  ifscOrSwift: string;
  branch?: string;
  instructions?: string;
}

interface AppState {
  currentUser: User | null;
  users: User[];
  transactions: Transaction[];
  recharges: Recharge[];
  withdrawals: Withdrawal[];
  bankAccounts: BankAccount[];
  interestLogs: InterestLog[];
  platformBank: PlatformBank;
  login: (email: string, password: string) => User;
  register: (name: string, email: string, password: string) => User;
  logout: () => void;
  submitRecharge: (amount: number, note: string) => void;
  reviewRecharge: (id: string, status: "approved" | "rejected", remarks: string) => void;
  addBankAccount: (b: Omit<BankAccount, "id">) => void;
  submitWithdrawal: (bankAccountId: string, amount: number) => void;
  processWithdrawal: (id: string, status: "paid" | "rejected", remarks: string) => void;
  updateInterest: (dailyPercent: number, note: string) => void;
  updatePlatformBank: (b: PlatformBank) => void;
}

const Ctx = createContext<AppState | null>(null);

const now = () => new Date().toISOString();
const uid = () => Math.random().toString(36).slice(2, 10);

const seedUser: User = {
  id: "u_demo",
  name: "Aarav Mehta",
  email: "demo@tradenix.com",
  role: "user",
  balance: 142_580.42,
  joined: "2025-02-14T09:00:00Z",
};

const seedUsers: User[] = [
  seedUser,
  { id: "u_2", name: "Priya Iyer", email: "priya@example.com", role: "user", balance: 84210.0, joined: "2025-03-02T12:00:00Z" },
  { id: "u_3", name: "Liam Carter", email: "liam@example.com", role: "user", balance: 256401.55, joined: "2024-11-19T08:30:00Z" },
  { id: "u_4", name: "Mei Tanaka", email: "mei@example.com", role: "user", balance: 39800.1, joined: "2025-05-22T15:45:00Z" },
  { id: "u_5", name: "Diego Alvarez", email: "diego@example.com", role: "user", balance: 512200.7, joined: "2024-08-04T10:10:00Z" },
];

export function AppDataProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(seedUser);
  const [users, setUsers] = useState<User[]>(seedUsers);
  const [transactions, setTransactions] = useState<Transaction[]>([
    { id: uid(), userId: "u_demo", createdAt: "2026-05-30T10:12:00Z", type: "recharge", amount: 50000, balanceAfter: 50000, note: "Initial deposit" },
    { id: uid(), userId: "u_demo", createdAt: "2026-05-31T00:00:00Z", type: "interest_accrual", amount: 600, balanceAfter: 50600, note: "Daily accrual" },
    { id: uid(), userId: "u_demo", createdAt: "2026-06-01T11:30:00Z", type: "recharge", amount: 90000, balanceAfter: 140600, note: "Top-up" },
    { id: uid(), userId: "u_demo", createdAt: "2026-06-02T00:00:00Z", type: "interest_accrual", amount: 1980.42, balanceAfter: 142580.42, note: "Daily accrual" },
  ]);
  const [recharges, setRecharges] = useState<Recharge[]>([
    { id: uid(), userId: "u_2", userName: "Priya Iyer", amount: 25000, createdAt: "2026-06-02T08:00:00Z", status: "pending", paymentDescription: "UTR 88231100" },
    { id: uid(), userId: "u_4", userName: "Mei Tanaka", amount: 12000, createdAt: "2026-06-02T07:21:00Z", status: "pending" },
    { id: uid(), userId: "u_demo", userName: "Aarav Mehta", amount: 90000, createdAt: "2026-06-01T11:30:00Z", status: "approved", adminRemarks: "Verified" },
  ]);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([
    {
      id: uid(), userId: "u_3", userName: "Liam Carter", amount: 18000, createdAt: "2026-06-02T06:00:00Z", status: "pending",
      bankAccount: { id: uid(), accountHolderName: "Liam Carter", bankName: "HDFC", accountNumber: "5544221199", ifscOrSwift: "HDFC0001234" },
    },
  ]);
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([
    { id: "ba_1", accountHolderName: "Aarav Mehta", bankName: "ICICI Bank", accountNumber: "00112233445566", ifscOrSwift: "ICIC0004421", branch: "Mumbai Fort" },
  ]);
  const [interestLogs, setInterestLogs] = useState<InterestLog[]>([
    { id: uid(), dailyPercent: 1.4, effectiveFrom: "2026-06-01T00:00:00Z", changedBy: "admin@tradenix.com", note: "June rate" },
    { id: uid(), dailyPercent: 1.2, effectiveFrom: "2026-05-01T00:00:00Z", changedBy: "admin@tradenix.com", note: "May rate" },
    { id: uid(), dailyPercent: 1.0, effectiveFrom: "2026-04-01T00:00:00Z", changedBy: "admin@tradenix.com" },
  ]);
  const [platformBank, setPlatformBank] = useState<PlatformBank>({
    accountHolderName: "Tradenix Ventures Pvt Ltd",
    bankName: "Axis Bank",
    accountNumber: "9120 4455 7788 2231",
    ifscOrSwift: "UTIB0000123",
    branch: "Bangalore HSR Layout",
    instructions: "Use your registered email as the payment reference. Funds reflect within 2 hours after approval.",
  });

  // Live balance accrual every 3s for demo magic
  const rateRef = useRef(interestLogs[0]?.dailyPercent ?? 1.0);
  rateRef.current = interestLogs[0]?.dailyPercent ?? 1.0;
  useEffect(() => {
    const id = setInterval(() => {
      setCurrentUser((u) => {
        if (!u || u.role !== "user") return u;
        const perTick = (u.balance * rateRef.current) / 100 / (24 * 60 * 60 / 3);
        return { ...u, balance: u.balance + perTick };
      });
    }, 3000);
    return () => clearInterval(id);
  }, []);

  const value = useMemo<AppState>(() => ({
    currentUser, users, transactions, recharges, withdrawals, bankAccounts, interestLogs, platformBank,
    login: (email) => {
      const isAdmin = email.toLowerCase().includes("admin");
      const user: User = isAdmin
        ? { id: "u_admin", name: "Admin", email, role: "admin", balance: 0, joined: now() }
        : seedUser;
      setCurrentUser(user);
      return user;
    },
    register: (name, email) => {
      const user: User = { id: uid(), name, email, role: "user", balance: 0, joined: now() };
      setUsers((u) => [user, ...u]);
      setCurrentUser(user);
      return user;
    },
    logout: () => setCurrentUser(null),
    submitRecharge: (amount, note) => {
      if (!currentUser) return;
      setRecharges((r) => [
        { id: uid(), userId: currentUser.id, userName: currentUser.name, amount, createdAt: now(), status: "pending", paymentDescription: note },
        ...r,
      ]);
    },
    reviewRecharge: (id, status, remarks) => {
      setRecharges((rs) => rs.map((r) => r.id === id ? { ...r, status, adminRemarks: remarks } : r));
      if (status === "approved") {
        const target = recharges.find((r) => r.id === id);
        if (target) {
          setCurrentUser((u) => u && u.id === target.userId ? { ...u, balance: u.balance + target.amount } : u);
          setTransactions((t) => [{ id: uid(), userId: target.userId, createdAt: now(), type: "recharge", amount: target.amount, balanceAfter: (currentUser?.balance ?? 0) + target.amount, note: "Recharge approved" }, ...t]);
        }
      }
    },
    addBankAccount: (b) => setBankAccounts((bs) => [{ ...b, id: uid() }, ...bs]),
    submitWithdrawal: (bankAccountId, amount) => {
      if (!currentUser) return;
      const bank = bankAccounts.find((b) => b.id === bankAccountId);
      if (!bank) return;
      setWithdrawals((w) => [
        { id: uid(), userId: currentUser.id, userName: currentUser.name, amount, createdAt: now(), status: "pending", bankAccount: bank },
        ...w,
      ]);
    },
    processWithdrawal: (id, status, remarks) => {
      setWithdrawals((ws) => ws.map((w) => w.id === id ? { ...w, status, adminRemarks: remarks, paymentProofUrl: status === "paid" ? "#" : undefined } : w));
    },
    updateInterest: (dailyPercent, note) => {
      setInterestLogs((ls) => [{ id: uid(), dailyPercent, effectiveFrom: now(), changedBy: "admin@tradenix.com", note }, ...ls]);
    },
    updatePlatformBank: setPlatformBank,
  }), [currentUser, users, transactions, recharges, withdrawals, bankAccounts, interestLogs, platformBank]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useApp must be inside AppDataProvider");
  return ctx;
}

export const formatMoney = (n: number | undefined | null, currency = "₹") =>
  `${currency}${new Intl.NumberFormat("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n ?? 0)}`;

export const formatDate = (d: string | Date) =>
  new Date(d).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" });
