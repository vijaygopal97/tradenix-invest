import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Check, X, Image as ImageIcon } from "lucide-react";
import { AdminShell } from "../components/Shell";
import { Panel, SectionTitle, Input, Button, Badge, TableWrap, Th, Td } from "../components/ui-bits";
import { useApp, formatMoney, formatDate } from "../lib/store";

export const Route = createFileRoute("/admin/recharges")({
  component: RechargesPage,
});

const OPTIONS = ["all", "pending", "approved", "rejected"] as const;

function RechargesPage() {
  const { recharges, reviewRecharge } = useApp();
  const [filter, setFilter] = useState<string>("pending");
  const [remarks, setRemarks] = useState<Record<string, string>>({});

  const filtered = useMemo(() => filter === "all" ? recharges : recharges.filter((r) => r.status === filter), [recharges, filter]);
  const counts = useMemo(() => ({
    all: recharges.length,
    pending: recharges.filter(r => r.status === "pending").length,
    approved: recharges.filter(r => r.status === "approved").length,
    rejected: recharges.filter(r => r.status === "rejected").length,
  }), [recharges]);

  return (
    <AdminShell>
      <SectionTitle eyebrow="Approvals" title="Credit recharges" subtitle="Verify screenshots and notes before approving credits to user balances." />

      <div className="inline-flex items-center gap-1 p-1 rounded-full bg-white/[0.04] border border-white/5 mb-5">
        {OPTIONS.map((o) => (
          <button key={o} onClick={() => setFilter(o)}
            className={`px-4 py-1.5 text-xs font-medium rounded-full transition capitalize ${filter === o ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>
            {o} <span className="opacity-60 ml-1">{counts[o as keyof typeof counts]}</span>
          </button>
        ))}
      </div>

      <Panel className="p-0 overflow-hidden">
        <TableWrap>
          <thead>
            <tr><Th>Submitted</Th><Th>User</Th><Th className="text-right">Amount</Th><Th>Note</Th><Th>Receipt</Th><Th>Status</Th><Th>Remarks</Th><Th>Actions</Th></tr>
          </thead>
          <tbody>
            {filtered.map((r) => (
              <tr key={r.id} className="hover:bg-white/[0.02] transition">
                <Td className="text-muted-foreground whitespace-nowrap">{formatDate(r.createdAt)}</Td>
                <Td>
                  <div className="flex items-center gap-2.5">
                    <div className="h-8 w-8 rounded-full bg-white/[0.06] grid place-items-center text-xs font-semibold">{r.userName[0]}</div>
                    <span>{r.userName}</span>
                  </div>
                </Td>
                <Td className="text-right font-mono">{formatMoney(r.amount)}</Td>
                <Td className="text-muted-foreground max-w-[180px] truncate">{r.paymentDescription ?? "—"}</Td>
                <Td>
                  <button className="inline-flex items-center gap-1.5 text-xs text-primary hover:underline">
                    <ImageIcon className="h-3.5 w-3.5" /> View
                  </button>
                </Td>
                <Td><Badge status={r.status} /></Td>
                <Td>
                  {r.status === "pending" ? (
                    <Input className="!py-2 !text-xs w-44" placeholder="Optional remarks…" value={remarks[r.id] ?? ""} onChange={(e) => setRemarks({ ...remarks, [r.id]: e.target.value })} />
                  ) : (
                    <span className="text-xs text-muted-foreground">{r.adminRemarks ?? "—"}</span>
                  )}
                </Td>
                <Td>
                  {r.status === "pending" ? (
                    <div className="flex gap-2">
                      <Button size="sm" onClick={() => reviewRecharge(r.id, "approved", remarks[r.id] ?? "")}><Check className="h-3.5 w-3.5" /> Approve</Button>
                      <Button size="sm" variant="danger" onClick={() => reviewRecharge(r.id, "rejected", remarks[r.id] ?? "")}><X className="h-3.5 w-3.5" /> Reject</Button>
                    </div>
                  ) : <span className="text-xs text-muted-foreground">—</span>}
                </Td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><Td className="text-center text-muted-foreground">Nothing here.</Td><Td /><Td /><Td /><Td /><Td /><Td /><Td /></tr>}
          </tbody>
        </TableWrap>
      </Panel>
    </AdminShell>
  );
}
