import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowDownLeft, ArrowUpRight, Percent, Coins } from "lucide-react";
import { UserShell } from "../components/Shell";
import { Panel, SectionTitle, TableWrap, Th, Td } from "../components/ui-bits";
import { useApp, formatMoney, formatDate } from "../lib/store";

export const Route = createFileRoute("/transactions")({
  component: TxPage,
});

const iconFor: Record<string, any> = {
  recharge: ArrowDownLeft,
  withdrawal: ArrowUpRight,
  interest_accrual: Percent,
  adjustment: Coins,
};

function TxPage() {
  const { transactions, currentUser } = useApp();
  const [type, setType] = useState<string>("all");
  const mine = transactions.filter((t) => t.userId === (currentUser?.id ?? "u_demo"));
  const filtered = type === "all" ? mine : mine.filter((t) => t.type === type);

  const tabs = [
    { v: "all", l: "All" },
    { v: "recharge", l: "Deposits" },
    { v: "withdrawal", l: "Withdrawals" },
    { v: "interest_accrual", l: "Interest" },
  ];

  return (
    <UserShell>
      <SectionTitle eyebrow="Ledger" title="Transaction history" subtitle="Every credit and debit, accounted for." />

      <div className="inline-flex items-center gap-1 p-1 rounded-full bg-white/[0.04] border border-white/5 mb-5">
        {tabs.map((t) => (
          <button
            key={t.v}
            onClick={() => setType(t.v)}
            className={`px-4 py-1.5 text-xs font-medium rounded-full transition ${type === t.v ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
          >{t.l}</button>
        ))}
      </div>

      <Panel className="p-0 overflow-hidden">
        <TableWrap>
          <thead>
            <tr><Th>Date</Th><Th>Type</Th><Th className="text-right">Amount</Th><Th className="text-right">Balance</Th><Th>Note</Th></tr>
          </thead>
          <tbody>
            {filtered.length === 0 && <tr><Td className="text-muted-foreground text-center">No transactions found.</Td><Td /><Td /><Td /><Td /></tr>}
            {filtered.map((t) => {
              const Icon = iconFor[t.type] ?? Coins;
              const positive = t.amount >= 0;
              return (
                <tr key={t.id} className="hover:bg-white/[0.02] transition">
                  <Td className="text-muted-foreground whitespace-nowrap">{formatDate(t.createdAt)}</Td>
                  <Td>
                    <div className="flex items-center gap-2.5">
                      <div className={`h-8 w-8 rounded-lg grid place-items-center ${positive ? "bg-primary/10 text-primary" : "bg-destructive/10 text-destructive"}`}>
                        <Icon className="h-4 w-4" />
                      </div>
                      <span className="capitalize">{t.type.replace(/_/g, " ")}</span>
                    </div>
                  </Td>
                  <Td className={`text-right font-mono ${positive ? "text-primary" : "text-destructive"}`}>{positive ? "+" : ""}{formatMoney(t.amount)}</Td>
                  <Td className="text-right font-mono text-muted-foreground">{formatMoney(t.balanceAfter)}</Td>
                  <Td className="text-muted-foreground">{t.note ?? "—"}</Td>
                </tr>
              );
            })}
          </tbody>
        </TableWrap>
      </Panel>
    </UserShell>
  );
}
