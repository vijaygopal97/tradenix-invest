import { createFileRoute, Link } from "@tanstack/react-router";
import { Users, Wallet, Inbox, ArrowUpRight, TrendingUp } from "lucide-react";
import { AdminShell } from "../components/Shell";
import { Panel, SectionTitle, StatCard, Badge } from "../components/ui-bits";
import { useApp, formatMoney, formatDate } from "../lib/store";

export const Route = createFileRoute("/admin")({
  component: AdminDash,
});

function AdminDash() {
  const { users, recharges, withdrawals, interestLogs } = useApp();
  const totalCredits = users.reduce((s, u) => s + u.balance, 0);
  const pendingR = recharges.filter((r) => r.status === "pending").length;
  const pendingW = withdrawals.filter((w) => w.status === "pending").length;
  const rate = interestLogs[0]?.dailyPercent ?? 0;

  return (
    <AdminShell>
      <SectionTitle eyebrow="Overview" title="Mission control" subtitle="Live snapshot of platform health, capital, and pending approvals." />

      <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <StatCard delay={0.0} label="Active users" value={users.length} hint="Including admins" accent="primary" icon={Users} />
        <StatCard delay={0.05} label="Capital under platform" value={formatMoney(totalCredits)} hint="Real-time sum" accent="gold" icon={Wallet} />
        <StatCard delay={0.1} label="Pending recharges" value={pendingR} hint="Awaiting review" accent={pendingR > 0 ? "danger" : "primary"} icon={Inbox} />
        <StatCard delay={0.15} label="Pending withdrawals" value={pendingW} hint="Awaiting payout" accent={pendingW > 0 ? "danger" : "primary"} icon={ArrowUpRight} />
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <Panel className="lg:col-span-2">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="font-display text-xl">Capital flow</h3>
              <p className="text-xs text-muted-foreground mt-1">Net deposits last 14 days</p>
            </div>
            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs">
              <TrendingUp className="h-3.5 w-3.5" /> +18.6%
            </div>
          </div>
          <Bars />
        </Panel>

        <Panel>
          <h3 className="font-display text-xl mb-4">Top investors</h3>
          <div className="space-y-3">
            {[...users].sort((a, b) => b.balance - a.balance).slice(0, 5).map((u, i) => (
              <Link key={u.id} to={`/admin/users/${u.id}`} className="flex items-center gap-3 p-2 -mx-2 rounded-xl hover:bg-white/[0.04] transition">
                <div className="text-xs text-muted-foreground w-5">{i + 1}</div>
                <div className="h-8 w-8 rounded-full bg-gradient-to-br from-primary/40 to-accent/40 grid place-items-center text-xs font-semibold">{u.name[0]}</div>
                <div className="min-w-0 flex-1">
                  <div className="text-sm truncate">{u.name}</div>
                  <div className="text-[10px] text-muted-foreground truncate">{u.email}</div>
                </div>
                <div className="text-sm font-mono">{formatMoney(u.balance)}</div>
              </Link>
            ))}
          </div>
        </Panel>
      </div>

      <Panel className="mt-4">
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-display text-xl">Latest pending approvals</h3>
          <Link to="/admin/recharges" className="text-xs text-primary hover:underline">Open queue →</Link>
        </div>
        <div className="space-y-2">
          {recharges.filter(r => r.status === "pending").slice(0, 4).map((r) => (
            <div key={r.id} className="flex items-center justify-between p-3 rounded-xl hover:bg-white/[0.03] transition">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-lg bg-white/[0.06] grid place-items-center text-sm font-semibold">{r.userName[0]}</div>
                <div>
                  <div className="text-sm">{r.userName}</div>
                  <div className="text-xs text-muted-foreground">{formatDate(r.createdAt)}</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="font-mono">{formatMoney(r.amount)}</div>
                <Badge status={r.status} />
              </div>
            </div>
          ))}
          {recharges.filter(r => r.status === "pending").length === 0 && <p className="text-sm text-muted-foreground">All caught up. 🎉</p>}
        </div>
        <div className="mt-5 text-xs text-muted-foreground">Current daily rate: <span className="text-primary font-mono">{rate.toFixed(2)}%</span></div>
      </Panel>
    </AdminShell>
  );
}

function Bars() {
  const data = [42, 58, 36, 71, 64, 88, 52, 76, 92, 68, 84, 96, 79, 110];
  const max = Math.max(...data);
  return (
    <div className="flex items-end gap-2 h-44">
      {data.map((d, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-2">
          <div
            className="w-full bg-gradient-to-t from-primary/40 to-primary rounded-md hover:from-primary/60 transition"
            style={{ height: `${(d / max) * 100}%` }}
          />
          <div className="text-[9px] text-muted-foreground">{i + 1}</div>
        </div>
      ))}
    </div>
  );
}
