import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronLeft } from "lucide-react";
import { AdminShell } from "../components/Shell";
import { Panel, SectionTitle, StatCard, Badge, TableWrap, Th, Td } from "../components/ui-bits";
import { useApp, formatMoney, formatDate } from "../lib/store";

export const Route = createFileRoute("/admin/users/$id")({
  component: UserDetail,
});

function UserDetail() {
  const { id } = Route.useParams();
  const { users, transactions, recharges, withdrawals } = useApp();
  const user = users.find((u) => u.id === id);
  if (!user) {
    return (
      <AdminShell>
        <Link to="/admin/users" className="text-sm text-muted-foreground hover:text-foreground inline-flex items-center gap-1"><ChevronLeft className="h-4 w-4" />Back</Link>
        <Panel className="mt-4">User not found.</Panel>
      </AdminShell>
    );
  }
  const tx = transactions.filter((t) => t.userId === id);
  const rs = recharges.filter((r) => r.userId === id);
  const ws = withdrawals.filter((w) => w.userId === id);

  return (
    <AdminShell>
      <Link to="/admin/users" className="text-sm text-muted-foreground hover:text-foreground inline-flex items-center gap-1 mb-4"><ChevronLeft className="h-4 w-4" />Users</Link>
      <div className="flex items-center gap-4 mb-6">
        <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-primary to-accent grid place-items-center font-display text-2xl text-primary-foreground">{user.name[0]}</div>
        <div>
          <h1 className="font-display text-3xl">{user.name}</h1>
          <p className="text-muted-foreground text-sm">{user.email} · joined {formatDate(user.joined)}</p>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4 mb-6">
        <StatCard label="Current balance" value={formatMoney(user.balance)} accent="primary" />
        <StatCard label="Recharges" value={rs.length} hint={`${rs.filter(r=>r.status==='approved').length} approved`} />
        <StatCard label="Withdrawals" value={ws.length} hint={`${ws.filter(w=>w.status==='paid').length} paid`} accent="gold" />
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Panel>
          <h3 className="font-display text-xl mb-4">Recharges</h3>
          <TableWrap>
            <thead><tr><Th>Date</Th><Th>Amount</Th><Th>Status</Th></tr></thead>
            <tbody>
              {rs.map((r) => (
                <tr key={r.id}><Td className="text-muted-foreground">{formatDate(r.createdAt)}</Td><Td className="font-mono">{formatMoney(r.amount)}</Td><Td><Badge status={r.status} /></Td></tr>
              ))}
              {rs.length === 0 && <tr><Td className="text-muted-foreground" /><Td /><Td /></tr>}
            </tbody>
          </TableWrap>
        </Panel>
        <Panel>
          <h3 className="font-display text-xl mb-4">Withdrawals</h3>
          <TableWrap>
            <thead><tr><Th>Date</Th><Th>Amount</Th><Th>Status</Th></tr></thead>
            <tbody>
              {ws.map((w) => (
                <tr key={w.id}><Td className="text-muted-foreground">{formatDate(w.createdAt)}</Td><Td className="font-mono">{formatMoney(w.amount)}</Td><Td><Badge status={w.status} /></Td></tr>
              ))}
              {ws.length === 0 && <tr><Td className="text-muted-foreground" /><Td /><Td /></tr>}
            </tbody>
          </TableWrap>
        </Panel>
      </div>

      <Panel className="mt-4">
        <h3 className="font-display text-xl mb-4">Transactions</h3>
        <TableWrap>
          <thead><tr><Th>Date</Th><Th>Type</Th><Th className="text-right">Amount</Th><Th className="text-right">Balance</Th></tr></thead>
          <tbody>
            {tx.map((t) => (
              <tr key={t.id}>
                <Td className="text-muted-foreground">{formatDate(t.createdAt)}</Td>
                <Td className="capitalize">{t.type.replace(/_/g, " ")}</Td>
                <Td className={`text-right font-mono ${t.amount >= 0 ? "text-primary" : "text-destructive"}`}>{t.amount >= 0 ? "+" : ""}{formatMoney(t.amount)}</Td>
                <Td className="text-right font-mono">{formatMoney(t.balanceAfter)}</Td>
              </tr>
            ))}
            {tx.length === 0 && <tr><Td className="text-muted-foreground">No transactions.</Td><Td /><Td /><Td /></tr>}
          </tbody>
        </TableWrap>
      </Panel>
    </AdminShell>
  );
}
