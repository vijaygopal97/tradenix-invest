import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AdminShell } from "../components/Shell";
import { Panel, SectionTitle, Field, Input, Textarea, Button, Alert } from "../components/ui-bits";
import { useApp } from "../lib/store";

export const Route = createFileRoute("/admin/bank")({
  component: BankPage,
});

function BankPage() {
  const { platformBank, updatePlatformBank } = useApp();
  const [form, setForm] = useState(platformBank);
  const [msg, setMsg] = useState("");
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    updatePlatformBank(form);
    setMsg("Platform bank details saved.");
  };
  return (
    <AdminShell>
      <SectionTitle eyebrow="Banking" title="Platform bank details" subtitle="Visible to all investors on the Invest page." />
      {msg && <div className="mb-4"><Alert tone="success">{msg}</Alert></div>}
      <Panel>
        <form onSubmit={submit} className="grid md:grid-cols-2 gap-4">
          <Field label="Account holder"><Input value={form.accountHolderName} onChange={(e) => setForm({ ...form, accountHolderName: e.target.value })} required /></Field>
          <Field label="Bank name"><Input value={form.bankName} onChange={(e) => setForm({ ...form, bankName: e.target.value })} required /></Field>
          <Field label="Account number"><Input value={form.accountNumber} onChange={(e) => setForm({ ...form, accountNumber: e.target.value })} required /></Field>
          <Field label="IFSC / SWIFT"><Input value={form.ifscOrSwift} onChange={(e) => setForm({ ...form, ifscOrSwift: e.target.value })} required /></Field>
          <Field label="Branch"><Input value={form.branch ?? ""} onChange={(e) => setForm({ ...form, branch: e.target.value })} /></Field>
          <div className="md:col-span-2">
            <Field label="Instructions">
              <Textarea rows={3} value={form.instructions ?? ""} onChange={(e) => setForm({ ...form, instructions: e.target.value })} />
            </Field>
          </div>
          <div className="md:col-span-2 flex justify-end">
            <Button type="submit">Save details</Button>
          </div>
        </form>
      </Panel>
    </AdminShell>
  );
}
