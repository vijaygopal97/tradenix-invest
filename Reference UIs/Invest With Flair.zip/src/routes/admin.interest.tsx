import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { TrendingUp } from "lucide-react";
import { AdminShell } from "../components/Shell";
import { Panel, SectionTitle, Field, Input, Button, Alert, TableWrap, Th, Td } from "../components/ui-bits";
import { useApp, formatDate } from "../lib/store";

export const Route = createFileRoute("/admin/interest")({
  component: InterestPage,
});

function InterestPage() {
  const { interestLogs, updateInterest } = useApp();
  const current = interestLogs[0]?.dailyPercent;
  const [rate, setRate] = useState("");
  const [note, setNote] = useState("");
  const [msg, setMsg] = useState("");
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    updateInterest(Number(rate), note);
    setRate(""); setNote("");
    setMsg("Daily rate updated — applies prospectively.");
  };
  return (
    <AdminShell>
      <SectionTitle eyebrow="Interest" title="Rate management" subtitle="Changes apply from the moment you save them. Past accrual is preserved." />

      <div className="grid lg:grid-cols-[1.2fr_2fr] gap-5">
        <Panel className="relative overflow-hidden">
          <div className="absolute -top-16 -right-16 h-44 w-44 rounded-full bg-primary/20 blur-3xl" />
          <div className="relative">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Current daily rate</div>
            <div className="font-display text-6xl mt-2 text-gradient">{current?.toFixed(2)}%</div>
            <div className="inline-flex items-center gap-1 mt-2 text-xs text-primary">
              <TrendingUp className="h-3.5 w-3.5" /> Compounded continuously
            </div>
          </div>
          {msg && <div className="mt-5"><Alert tone="success">{msg}</Alert></div>}
          <form onSubmit={submit} className="mt-5 space-y-4">
            <Field label="New daily rate (%)"><Input type="number" min="0" step="0.01" value={rate} onChange={(e) => setRate(e.target.value)} placeholder="1.40" required /></Field>
            <Field label="Note (optional)"><Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Why are you changing this?" /></Field>
            <Button type="submit" full>Update rate</Button>
          </form>
        </Panel>

        <Panel className="p-0 overflow-hidden">
          <div className="p-6"><h3 className="font-display text-xl">Change history</h3></div>
          <TableWrap>
            <thead><tr><Th>Effective from</Th><Th>Daily %</Th><Th>Changed by</Th><Th>Note</Th></tr></thead>
            <tbody>
              {interestLogs.map((l) => (
                <tr key={l.id}>
                  <Td className="text-muted-foreground">{formatDate(l.effectiveFrom)}</Td>
                  <Td className="font-mono text-primary">{l.dailyPercent.toFixed(2)}%</Td>
                  <Td>{l.changedBy}</Td>
                  <Td className="text-muted-foreground">{l.note ?? "—"}</Td>
                </tr>
              ))}
            </tbody>
          </TableWrap>
        </Panel>
      </div>
    </AdminShell>
  );
}
