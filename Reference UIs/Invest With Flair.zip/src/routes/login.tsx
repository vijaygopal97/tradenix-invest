import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useState } from "react";
import { AuthLayout } from "../components/Shell";
import { Field, Input, Button, Alert } from "../components/ui-bits";
import { useApp } from "../lib/store";

export const Route = createFileRoute("/login")({
  component: LoginPage,
});

function LoginPage() {
  const { login } = useApp();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setBusy(true);
    setTimeout(() => {
      const user = login(email, password);
      router.navigate({ to: user.role === "admin" ? "/admin" : "/dashboard" });
    }, 500);
  };

  return (
    <AuthLayout
      title="Welcome back"
      subtitle="Sign in to your investor console. Tip: include “admin” in the email for admin demo."
      footer={<>New here? <Link to="/register" className="text-primary hover:underline">Create an account</Link></>}
    >
      <form onSubmit={submit} className="space-y-5">
        {error && <Alert tone="error">{error}</Alert>}
        <Field label="Email"><Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@tradenix.com" required /></Field>
        <Field label="Password"><Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" required /></Field>
        <Button type="submit" full disabled={busy}>{busy ? "Signing in…" : "Sign in"}</Button>
      </form>
    </AuthLayout>
  );
}
