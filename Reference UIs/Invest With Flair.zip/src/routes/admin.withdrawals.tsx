import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Check, X, Upload } from "lucide-react";
import { AdminShell } from "../components/Shell";
import { Panel, SectionTitle, Input, Button, Badge, TableWrap, Th, Td, Alert } from "../components/ui-bits";
import { useApp, formatMoney, formatDate } from "../lib/store";

export const Route = createFileRoute("/admin/withdrawals")({
  component: WPage,
});

const OPTIONS = ["all", "pending", "paid", "rejected"] as const;

function WPage() {
  const { withdrawals, processWithdrawal } = useApp();
  const [filter, setFilter] = useState<string>("pending");
  const [remarks, setRemarks] = useState<Record<string, string>>({});
  const [proofs, setProofs] = useState<Record<string, File | null>>({});
  const [err, setErr] = useState("");

  const filtered = useMemo(() => filter === "all" ? withdrawals : withdrawals.filter((w) => w.status === filter), [withdrawals, filter]);
  const counts = useMemo(() => ({
    all: withdrawals.length,
    pending: withdrawals.filter(w => w.status === "pending").length,
    paid: withdrawals.filter(w => w.status === "paid").length,
    rejected: withdrawals.filter(w => w.status === "rejected").length,
  }), [withdrawals]);

  const pay = (id: string) => {
    setErr("");
    if (!proofs[id]) { setErr("Upload payment proof before marking paid."); return; }
    processWithdrawal(id, "paid", remarks[id] ?? "");
  };
  const reject = (id: string) => processWithdrawal(id, "rejected", remarks[id] ?? "");

  return (
    <AdminShell>
      <SectionTitle eyebrow="Approvals" title="Withdrawal queue" subtitle="Process payouts, attach proof and notify investors." />

      {err && <div className="mb-4"><Alert tone="error">{err}</Alert></div>}

      <div className="inline-flex items-center gap-1 p-1 rounded-full bg-white/[0.04] border border-white/5 mb-5">
        {OPTIONS.map((o) => (
          <button key={o} onClick={() => setFilter(o)}
            className={`px-4 py-1.5 text-xs font-medium rounded-full transition capitalize ${filter === o ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>
            {o} <span className="opacity-60 ml-1">{counts[o as keyof typeof counts]}</span>
          </button>
        ))}
      </div>

      <Panel className="p-0 overflow-hidden">
        <TableWrap>
          <thead>
            <tr><Th>Requested</Th><Th>User</Th><Th className="text-right">Amount</Th><Th>Bank</Th><Th>Status</Th><Th>Proof</Th><Th>Remarks</Th><Th>Actions</Th></tr>
          </thead>
          <tbody>
            {filtered.map((w) => (
              <tr key={w.id} className="hover:bg-white/[0.02] transition">
                <Td className="text-muted-foreground whitespace-nowrap">{formatDate(w.createdAt)}</Td>
                <Td>
                  <div className="flex items-center gap-2.5">
                    <div className="h-8 w-8 rounded-full bg-white/[0.06] grid place-items-center text-xs font-semibold">{w.userName[0]}</div>
                    <span>{w.userName}</span>
                  </div>
                </Td>
                <Td className="text-right font-mono">{formatMoney(w.amount)}</Td>
                <Td>
                  <div className="text-sm">{w.bankAccount.bankName}</div>
                  <div className="text-xs text-muted-foreground font-mono">••••{w.bankAccount.accountNumber.slice(-4)}</div>
                </Td>
                <Td><Badge status={w.status} /></Td>
                <Td>
                  {w.status === "pending" ? (
                    <label className="inline-flex items-center gap-1.5 text-xs text-primary hover:underline cursor-pointer">
                      <input type="file" accept="image/*" className="hidden" onChange={(e) => setProofs({ ...proofs, [w.id]: e.target.files?.[0] ?? null })} />
                      <Upload className="h-3.5 w-3.5" /> {proofs[w.id] ? proofs[w.id]!.name.slice(0, 14) + "…" : "Upload proof"}
                    </label>
                  ) : w.paymentProofUrl ? (
                    <a href={w.paymentProofUrl} className="text-xs text-primary hover:underline">View</a>
                  ) : "—"}
                </Td>
                <Td>
                  {w.status === "pending" ? (
                    <Input className="!py-2 !text-xs w-40" placeholder="Optional…" value={remarks[w.id] ?? ""} onChange={(e) => setRemarks({ ...remarks, [w.id]: e.target.value })} />
                  ) : <span className="text-xs text-muted-foreground">{w.adminRemarks ?? "—"}</span>}
                </Td>
                <Td>
                  {w.status === "pending" ? (
                    <div className="flex gap-2">
                      <Button size="sm" onClick={() => pay(w.id)}><Check className="h-3.5 w-3.5" /> Mark paid</Button>
                      <Button size="sm" variant="danger" onClick={() => reject(w.id)}><X className="h-3.5 w-3.5" /> Reject</Button>
                    </div>
                  ) : <span className="text-xs text-muted-foreground">—</span>}
                </Td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><Td className="text-center text-muted-foreground">Nothing here.</Td><Td /><Td /><Td /><Td /><Td /><Td /><Td /></tr>}
          </tbody>
        </TableWrap>
      </Panel>
    </AdminShell>
  );
}
