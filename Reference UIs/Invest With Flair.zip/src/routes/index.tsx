import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowRight, ShieldCheck, Zap, TrendingUp, Clock, Lock, Sparkles } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Tradenix Venture — Credit growth, reimagined" },
      { name: "description", content: "Compound your capital with daily interest. Built for serious investors who want clarity, control and conviction." },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="relative overflow-hidden">
      {/* Nav */}
      <header className="relative z-20">
        <nav className="max-w-7xl mx-auto flex items-center justify-between px-6 py-5">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-primary to-accent grid place-items-center font-display font-bold text-primary-foreground">T</div>
            <div className="leading-tight">
              <div className="font-display font-semibold">Tradenix</div>
              <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Venture</div>
            </div>
          </Link>
          <div className="hidden md:flex items-center gap-8 text-sm text-muted-foreground">
            <a href="#how" className="hover:text-foreground transition">How it works</a>
            <a href="#features" className="hover:text-foreground transition">Features</a>
            <a href="#trust" className="hover:text-foreground transition">Trust</a>
          </div>
          <div className="flex items-center gap-2">
            <Link to="/login" className="text-sm px-4 py-2 rounded-full hover:bg-white/5 transition">Sign in</Link>
            <Link to="/register" className="text-sm px-4 py-2 rounded-full bg-primary text-primary-foreground font-semibold hover:scale-[1.03] transition">Get started</Link>
          </div>
        </nav>
      </header>

      {/* Hero */}
      <section className="relative max-w-7xl mx-auto px-6 pt-16 pb-24 lg:pt-24 lg:pb-36">
        <div className="absolute inset-0 grid-pattern opacity-30 pointer-events-none" />
        <div className="absolute top-1/3 -left-40 h-96 w-96 rounded-full bg-primary/20 blur-[120px]" />
        <div className="absolute top-10 right-0 h-96 w-96 rounded-full bg-accent/20 blur-[120px]" />

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="relative max-w-3xl"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-white/10 bg-white/[0.03] backdrop-blur text-xs">
            <Sparkles className="h-3.5 w-3.5 text-primary" />
            <span className="text-muted-foreground">Now compounding at <span className="text-primary font-mono">1.40% / day</span></span>
          </div>
          <h1 className="mt-6 font-display font-semibold tracking-tight text-5xl lg:text-7xl leading-[1.05]">
            Capital that <span className="text-gradient-gold">compounds</span> while you sleep.
          </h1>
          <p className="mt-6 text-lg text-muted-foreground max-w-2xl">
            Tradenix Venture is a credit growth platform engineered for serious investors. Deposit, watch your balance accrue every second, withdraw on your schedule — all from one obsessively clean interface.
          </p>
          <div className="mt-10 flex flex-wrap items-center gap-3">
            <Link to="/register" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-primary text-primary-foreground font-semibold shine-on-hover hover:shadow-[0_15px_40px_-10px] hover:shadow-primary/60 transition">
              Open an account <ArrowRight className="h-4 w-4" />
            </Link>
            <Link to="/login" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/10 hover:bg-white/5 transition">
              Sign in to dashboard
            </Link>
          </div>

          <div className="mt-14 grid grid-cols-3 max-w-xl gap-8">
            {[
              { v: "₹284Cr", l: "Capital under platform" },
              { v: "12,400+", l: "Active investors" },
              { v: "1.4%", l: "Avg. daily yield" },
            ].map((s, i) => (
              <motion.div
                key={s.l}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + i * 0.1 }}
              >
                <div className="font-display text-2xl text-gradient">{s.v}</div>
                <div className="text-xs text-muted-foreground mt-1">{s.l}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Floating card mosaic */}
        <motion.div
          initial={{ opacity: 0, x: 40 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.9, delay: 0.2, ease: "easeOut" }}
          className="hidden xl:block absolute right-6 top-24 w-[440px]"
        >
          <div className="relative">
            <div className="glass-panel-strong p-6 relative">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Live balance</span>
                <span className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" /> Streaming</span>
              </div>
              <div className="font-display text-4xl mt-2 text-gradient">₹1,42,580.42</div>
              <div className="text-xs text-primary mt-1 font-mono">+ ₹19.83 this minute</div>
              <div className="mt-5 grid grid-cols-2 gap-3">
                <div className="rounded-xl bg-white/[0.04] p-3">
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Daily</div>
                  <div className="font-mono mt-1 text-primary">+1.40%</div>
                </div>
                <div className="rounded-xl bg-white/[0.04] p-3">
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wider">30-day</div>
                  <div className="font-mono mt-1 text-primary">+42.18%</div>
                </div>
              </div>
            </div>
            <motion.div animate={{ y: [0, -8, 0] }} transition={{ duration: 5, repeat: Infinity }} className="glass-panel-strong absolute -top-8 -left-12 p-3.5 flex items-center gap-3">
              <div className="h-9 w-9 rounded-full bg-primary/20 grid place-items-center"><TrendingUp className="h-4 w-4 text-primary" /></div>
              <div><div className="text-xs text-muted-foreground">Withdrawal sent</div><div className="text-sm font-medium">₹25,000 → ICICI</div></div>
            </motion.div>
            <motion.div animate={{ y: [0, 8, 0] }} transition={{ duration: 6, repeat: Infinity, delay: 0.5 }} className="glass-panel-strong absolute -bottom-8 -right-6 p-3.5 flex items-center gap-3">
              <div className="h-9 w-9 rounded-full bg-accent/20 grid place-items-center"><ShieldCheck className="h-4 w-4 text-accent" /></div>
              <div><div className="text-xs text-muted-foreground">Verified</div><div className="text-sm font-medium">256-bit secured</div></div>
            </motion.div>
          </div>
        </motion.div>
      </section>

      {/* Ticker */}
      <section className="relative border-y border-white/5 py-5 overflow-hidden bg-ink/40">
        <div className="flex gap-12 animate-ticker whitespace-nowrap">
          {[...Array(2)].flatMap((_, k) => ["NIFTY 24,318 +0.42%", "BTC ₹52,11,400 +1.8%", "ETH ₹2,15,800 +2.1%", "Gold ₹71,200 +0.3%", "Tradenix Index 1428.6 +1.4%", "USD/INR 83.21 -0.1%"].map((t, i) => (
            <span key={`${k}-${i}`} className="text-sm text-muted-foreground font-mono">
              <span className="mr-2 text-primary">●</span>{t}
            </span>
          )))}
        </div>
      </section>

      {/* Features */}
      <section id="features" className="max-w-7xl mx-auto px-6 py-24">
        <div className="max-w-2xl">
          <div className="text-[11px] uppercase tracking-[0.2em] text-primary mb-3">Why Tradenix</div>
          <h2 className="font-display text-4xl lg:text-5xl tracking-tight">Designed for clarity, built for compounding.</h2>
        </div>
        <div className="mt-14 grid md:grid-cols-3 gap-5">
          {[
            { i: Zap, t: "Real-time accrual", d: "Watch your balance grow every three seconds as daily interest compounds in front of your eyes." },
            { i: Clock, t: "Instant recharges", d: "Upload your payment proof, get verified within hours, and start earning before the next sunrise." },
            { i: Lock, t: "Bank-grade security", d: "End-to-end encryption, role-isolated access, and admin-reviewed withdrawals — every step audited." },
            { i: TrendingUp, t: "Transparent yields", d: "Admin-set rates published with full history. No surprise fees, no hidden lock-ups." },
            { i: ShieldCheck, t: "Verified withdrawals", d: "Each payout is processed against your saved bank account with proof attached." },
            { i: Sparkles, t: "Effortless UX", d: "A console so clean it almost disappears — your numbers do all the talking." },
          ].map((f, i) => (
            <motion.div
              key={f.t}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="glass-panel p-6 group hover:border-primary/30 transition"
            >
              <div className="h-11 w-11 rounded-xl bg-primary/10 grid place-items-center group-hover:bg-primary/20 transition">
                <f.i className="h-5 w-5 text-primary" />
              </div>
              <h3 className="mt-4 font-display text-xl">{f.t}</h3>
              <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{f.d}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="max-w-7xl mx-auto px-6 py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="text-[11px] uppercase tracking-[0.2em] text-primary mb-3">How it works</div>
            <h2 className="font-display text-4xl lg:text-5xl tracking-tight">Three steps to compounding.</h2>
            <div className="mt-10 space-y-6">
              {[
                { n: "01", t: "Create an account", d: "Register in under 60 seconds. No paperwork rituals." },
                { n: "02", t: "Recharge your wallet", d: "Transfer to our verified bank account and attach the receipt." },
                { n: "03", t: "Watch it grow", d: "Daily interest compounds automatically. Withdraw whenever you want." },
              ].map((s) => (
                <div key={s.n} className="flex gap-5">
                  <div className="font-display text-3xl text-gradient-gold w-14 shrink-0">{s.n}</div>
                  <div>
                    <h3 className="font-display text-xl">{s.t}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{s.d}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="glass-panel-strong p-8">
            <div className="text-xs text-muted-foreground">Today's snapshot</div>
            <div className="font-display text-5xl mt-2 text-gradient">+₹1,980.42</div>
            <div className="text-sm text-muted-foreground">earned in last 24h</div>
            <Curve />
            <div className="mt-6 grid grid-cols-3 gap-3 text-sm">
              <div className="rounded-xl bg-white/[0.04] p-3">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Avg rate</div>
                <div className="font-mono mt-1">1.40%</div>
              </div>
              <div className="rounded-xl bg-white/[0.04] p-3">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Yield 30d</div>
                <div className="font-mono mt-1 text-primary">+42%</div>
              </div>
              <div className="rounded-xl bg-white/[0.04] p-3">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Streaks</div>
                <div className="font-mono mt-1">128d</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section id="trust" className="max-w-7xl mx-auto px-6 py-24">
        <div className="relative glass-panel-strong overflow-hidden p-12 lg:p-20 text-center">
          <div className="absolute -top-20 left-1/2 -translate-x-1/2 h-72 w-72 rounded-full bg-primary/30 blur-[120px]" />
          <h2 className="relative font-display text-4xl lg:text-6xl tracking-tight">Your money deserves<br />a better operating system.</h2>
          <p className="relative mt-5 text-muted-foreground max-w-xl mx-auto">Join 12,400+ investors compounding daily on Tradenix.</p>
          <Link to="/register" className="relative inline-flex items-center gap-2 mt-8 px-8 py-4 rounded-full bg-primary text-primary-foreground font-semibold shine-on-hover">
            Get started — it's free <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      <footer className="border-t border-white/5 mt-10 py-10 px-6">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between text-xs text-muted-foreground gap-4">
          <div>© 2026 Tradenix Venture. All rights reserved.</div>
          <div>Capital at risk. Past performance is not indicative of future returns.</div>
        </div>
      </footer>
    </div>
  );
}

function Curve() {
  const pts = [10, 14, 12, 22, 18, 30, 26, 38, 34, 48, 44, 60, 56, 72, 78];
  const max = Math.max(...pts);
  const d = pts.map((p, i) => `${i === 0 ? "M" : "L"} ${(i / (pts.length - 1)) * 100} ${100 - (p / max) * 95}`).join(" ");
  return (
    <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-32 mt-6">
      <defs>
        <linearGradient id="cg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="oklch(0.82 0.16 84)" stopOpacity="0.6" />
          <stop offset="100%" stopColor="oklch(0.82 0.16 84)" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={`${d} L 100 100 L 0 100 Z`} fill="url(#cg)" />
      <path d={d} stroke="oklch(0.82 0.16 84)" strokeWidth="2" fill="none" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}
