import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { UserShell } from "../components/Shell";
import { Panel, SectionTitle, Field, Input, Select, Button, Badge, TableWrap, Th, Td, Alert } from "../components/ui-bits";
import { useApp, formatMoney, formatDate } from "../lib/store";

export const Route = createFileRoute("/withdraw")({
  component: WithdrawPage,
});

const emptyBank = { accountHolderName: "", bankName: "", accountNumber: "", ifscOrSwift: "" };

function WithdrawPage() {
  const { currentUser, bankAccounts, withdrawals, addBankAccount, submitWithdrawal } = useApp();
  const [bank, setBank] = useState(emptyBank);
  const [bankId, setBankId] = useState(bankAccounts[0]?.id ?? "");
  const [amount, setAmount] = useState("");
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  const mine = withdrawals.filter((w) => w.userId === (currentUser?.id ?? "u_demo"));

  const saveBank = (e: React.FormEvent) => {
    e.preventDefault();
    addBankAccount(bank);
    setBank(emptyBank);
    setMsg("Bank account saved.");
  };
  const send = (e: React.FormEvent) => {
    e.preventDefault();
    setErr(""); setMsg("");
    if (!bankId) { setErr("Pick a bank account."); return; }
    submitWithdrawal(bankId, Number(amount));
    setAmount("");
    setMsg("Withdrawal request submitted.");
  };

  return (
    <UserShell>
      <SectionTitle eyebrow="Cash out" title="Withdraw" subtitle="Funds land in your bank within 24h after admin approval." />

      <Panel className="relative overflow-hidden mb-5">
        <div className="absolute -top-20 -right-20 h-48 w-48 rounded-full bg-primary/15 blur-3xl" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Available balance</div>
            <div className="font-display text-4xl mt-1 text-gradient tabular-nums">{formatMoney(currentUser?.balance)}</div>
          </div>
          <div className="text-xs text-muted-foreground max-w-xs">
            We process withdrawals in batches every 4 hours. You'll receive a payment proof once paid.
          </div>
        </div>
      </Panel>

      {msg && <div className="mb-4"><Alert tone="success">{msg}</Alert></div>}
      {err && <div className="mb-4"><Alert tone="error">{err}</Alert></div>}

      <div className="grid lg:grid-cols-2 gap-5 mb-6">
        <Panel>
          <h2 className="font-display text-2xl">Add a bank account</h2>
          <form onSubmit={saveBank} className="mt-5 space-y-4">
            <Field label="Account holder name"><Input value={bank.accountHolderName} onChange={(e) => setBank({ ...bank, accountHolderName: e.target.value })} required /></Field>
            <Field label="Bank name"><Input value={bank.bankName} onChange={(e) => setBank({ ...bank, bankName: e.target.value })} required /></Field>
            <Field label="Account number"><Input value={bank.accountNumber} onChange={(e) => setBank({ ...bank, accountNumber: e.target.value })} required /></Field>
            <Field label="IFSC / SWIFT"><Input value={bank.ifscOrSwift} onChange={(e) => setBank({ ...bank, ifscOrSwift: e.target.value })} required /></Field>
            <Button type="submit" variant="outline" full>Save account</Button>
          </form>
        </Panel>

        <Panel>
          <h2 className="font-display text-2xl">Request payout</h2>
          <form onSubmit={send} className="mt-5 space-y-4">
            <Field label="Send to">
              <Select value={bankId} onChange={(e) => setBankId(e.target.value)} required>
                <option value="">Choose account…</option>
                {bankAccounts.map((b) => (
                  <option key={b.id} value={b.id}>{b.bankName} — ••••{b.accountNumber.slice(-4)}</option>
                ))}
              </Select>
            </Field>
            <Field label="Amount (₹)"><Input type="number" min="1" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="5,000" required /></Field>
            <Button type="submit" full disabled={!bankAccounts.length}>Submit request</Button>
          </form>
        </Panel>
      </div>

      <Panel>
        <h3 className="font-display text-xl mb-5">Withdrawal history</h3>
        <TableWrap>
          <thead><tr><Th>Date</Th><Th>Amount</Th><Th>Bank</Th><Th>Status</Th><Th>Remarks</Th></tr></thead>
          <tbody>
            {mine.length === 0 && <tr><Td className="text-muted-foreground text-center">No withdrawals yet.</Td><Td /><Td /><Td /><Td /></tr>}
            {mine.map((w) => (
              <tr key={w.id} className="hover:bg-white/[0.02] transition">
                <Td className="text-muted-foreground">{formatDate(w.createdAt)}</Td>
                <Td className="font-mono">{formatMoney(w.amount)}</Td>
                <Td>{w.bankAccount.bankName}</Td>
                <Td><Badge status={w.status} /></Td>
                <Td className="text-muted-foreground">{w.adminRemarks || "—"}</Td>
              </tr>
            ))}
          </tbody>
        </TableWrap>
      </Panel>
    </UserShell>
  );
}
