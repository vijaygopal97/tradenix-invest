import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useState } from "react";
import { AuthLayout } from "../components/Shell";
import { Field, Input, Button, Alert } from "../components/ui-bits";
import { useApp } from "../lib/store";

export const Route = createFileRoute("/register")({
  component: RegisterPage,
});

function RegisterPage() {
  const { register } = useApp();
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setBusy(true);
    setTimeout(() => {
      register(name, email, password);
      router.navigate({ to: "/dashboard" });
    }, 500);
  };

  return (
    <AuthLayout
      title="Open your account"
      subtitle="Sixty seconds to start compounding."
      footer={<>Already with us? <Link to="/login" className="text-primary hover:underline">Sign in</Link></>}
    >
      <form onSubmit={submit} className="space-y-5">
        {error && <Alert tone="error">{error}</Alert>}
        <Field label="Full name"><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" required /></Field>
        <Field label="Email"><Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@email.com" required /></Field>
        <Field label="Password" hint="Minimum 6 characters."><Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} minLength={6} placeholder="Create a strong password" required /></Field>
        <Button type="submit" full disabled={busy}>{busy ? "Creating…" : "Create account"}</Button>
      </form>
    </AuthLayout>
  );
}
