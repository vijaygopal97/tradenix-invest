import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Search } from "lucide-react";
import { AdminShell } from "../components/Shell";
import { Panel, SectionTitle, Input, TableWrap, Th, Td } from "../components/ui-bits";
import { useApp, formatMoney, formatDate } from "../lib/store";

export const Route = createFileRoute("/admin/users")({
  component: UsersPage,
});

function UsersPage() {
  const { users } = useApp();
  const [q, setQ] = useState("");
  const filtered = users.filter((u) => u.name.toLowerCase().includes(q.toLowerCase()) || u.email.toLowerCase().includes(q.toLowerCase()));

  return (
    <AdminShell>
      <SectionTitle eyebrow="User management" title="Investors" subtitle="Search investors, review balances and open full account history." />

      <Panel className="mb-4">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input className="pl-11" placeholder="Search by name or email" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div className="flex items-center gap-4 mt-4 text-xs text-muted-foreground">
          <span>Total: <b className="text-foreground">{users.length}</b></span>
          <span>Showing: <b className="text-foreground">{filtered.length}</b></span>
        </div>
      </Panel>

      <Panel className="p-0 overflow-hidden">
        <TableWrap>
          <thead><tr><Th>User</Th><Th className="text-right">Balance</Th><Th>Joined</Th><Th /></tr></thead>
          <tbody>
            {filtered.map((u) => (
              <tr key={u.id} className="hover:bg-black/[0.02] transition">
                <Td>
                  <div className="flex items-center gap-3">
                    <div className="h-9 w-9 rounded-full bg-gradient-to-br from-primary/40 to-accent/40 grid place-items-center text-sm font-semibold">{u.name[0]}</div>
                    <div>
                      <div className="font-medium">{u.name}</div>
                      <div className="text-xs text-muted-foreground">{u.email}</div>
                    </div>
                  </div>
                </Td>
                <Td className="text-right font-mono">{formatMoney(u.balance)}</Td>
                <Td className="text-muted-foreground">{formatDate(u.joined)}</Td>
                <Td className="text-right">
                  <Link to={`/admin/users/${u.id}`} className="text-primary text-xs hover:underline">View details →</Link>
                </Td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><Td className="text-center text-muted-foreground">No users match your search.</Td><Td /><Td /><Td /></tr>}
          </tbody>
        </TableWrap>
      </Panel>
    </AdminShell>
  );
}
