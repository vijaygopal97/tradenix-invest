import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Upload, Copy, Check, Banknote, Sparkles } from "lucide-react";
import { UserShell } from "../components/Shell";
import { Panel, SectionTitle, Field, Input, Textarea, Button, Alert, Badge } from "../components/ui-bits";
import { useApp, formatMoney, formatDate } from "../lib/store";

export const Route = createFileRoute("/invest")({
  component: InvestPage,
});

function InvestPage() {
  const { platformBank, recharges, currentUser, submitRecharge } = useApp();
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  const [copied, setCopied] = useState<string | null>(null);

  const mine = recharges.filter((r) => r.userId === (currentUser?.id ?? "u_demo"));

  const copy = (v: string, k: string) => {
    navigator.clipboard?.writeText(v).then(() => {
      setCopied(k);
      setTimeout(() => setCopied(null), 1500);
    });
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setErr(""); setMsg("");
    if (!file) { setErr("Please upload a payment screenshot."); return; }
    submitRecharge(Number(amount), note);
    setAmount(""); setNote(""); setFile(null);
    (e.target as HTMLFormElement).reset();
    setMsg("Recharge submitted. We typically verify within 2 hours.");
  };

  return (
    <UserShell>
      <SectionTitle eyebrow="Add funds" title="Invest" subtitle="Transfer to our verified account, then attach your receipt." />

      <div className="grid lg:grid-cols-2 gap-5">
        <Panel className="relative overflow-hidden">
          <div className="absolute -top-20 -right-20 h-48 w-48 rounded-full bg-accent/15 blur-3xl" />
          <div className="relative">
            <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-accent">
              <Banknote className="h-4 w-4" /> Platform bank
            </div>
            <h2 className="font-display text-2xl mt-2">Send funds to</h2>

            <div className="mt-6 space-y-3">
              <BankRow label="Account holder" value={platformBank.accountHolderName} k="h" copied={copied} onCopy={copy} />
              <BankRow label="Bank" value={platformBank.bankName} k="b" copied={copied} onCopy={copy} />
              <BankRow label="Account number" value={platformBank.accountNumber} k="a" copied={copied} onCopy={copy} mono />
              <BankRow label="IFSC / SWIFT" value={platformBank.ifscOrSwift} k="i" copied={copied} onCopy={copy} mono />
              {platformBank.branch && <BankRow label="Branch" value={platformBank.branch} k="r" copied={copied} onCopy={copy} />}
            </div>
            {platformBank.instructions && (
              <div className="mt-5 p-3.5 rounded-xl bg-primary/5 border border-primary/20 text-xs text-primary/90 flex gap-2">
                <Sparkles className="h-4 w-4 shrink-0" />
                {platformBank.instructions}
              </div>
            )}
          </div>
        </Panel>

        <Panel>
          <h2 className="font-display text-2xl">Submit recharge</h2>
          <p className="text-sm text-muted-foreground mt-1">Attach the receipt for instant verification.</p>
          {msg && <div className="mt-4"><Alert tone="success">{msg}</Alert></div>}
          {err && <div className="mt-4"><Alert tone="error">{err}</Alert></div>}
          <form onSubmit={submit} className="mt-5 space-y-4">
            <Field label="Amount (₹)"><Input type="number" min="1" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="10,000" required /></Field>
            <Field label="Payment note" hint="UTR, reference, payer name — anything helping verification.">
              <Textarea rows={3} maxLength={500} value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g. UTR 88231100, paid via Yes Bank" />
            </Field>
            <Field label="Payment screenshot">
              <label className="block border-2 border-dashed border-black/10 hover:border-primary/50 rounded-xl px-5 py-8 cursor-pointer transition text-center">
                <input type="file" accept="image/*" onChange={(e) => setFile(e.target.files?.[0] ?? null)} className="hidden" required />
                <Upload className="h-6 w-6 mx-auto text-muted-foreground mb-2" />
                <div className="text-sm">{file ? file.name : "Drop or click to upload"}</div>
                <div className="text-xs text-muted-foreground mt-1">PNG, JPG up to 5MB</div>
              </label>
            </Field>
            <Button type="submit" full>Submit for approval</Button>
          </form>
        </Panel>
      </div>

      <Panel className="mt-6">
        <h3 className="font-display text-xl mb-4">Recent recharges</h3>
        <div className="space-y-2">
          {mine.length === 0 && <p className="text-sm text-muted-foreground">No recharges yet.</p>}
          {mine.map((r) => (
            <div key={r.id} className="flex items-center justify-between p-4 rounded-xl bg-black/[0.02] hover:bg-black/[0.03] transition">
              <div>
                <div className="font-mono text-sm">{formatMoney(r.amount)}</div>
                <div className="text-xs text-muted-foreground">{formatDate(r.createdAt)} · {r.paymentDescription ?? "—"}</div>
              </div>
              <Badge status={r.status} />
            </div>
          ))}
        </div>
      </Panel>
    </UserShell>
  );
}

function BankRow({ label, value, k, copied, onCopy, mono }: any) {
  return (
    <div className="flex items-center justify-between p-3.5 rounded-xl bg-black/[0.025] border border-black/5">
      <div>
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className={`mt-1 ${mono ? "font-mono" : ""}`}>{value}</div>
      </div>
      <button onClick={() => onCopy(value, k)} className="h-9 w-9 grid place-items-center rounded-lg hover:bg-black/[0.04] transition">
        {copied === k ? <Check className="h-4 w-4 text-primary" /> : <Copy className="h-4 w-4 text-muted-foreground" />}
      </button>
    </div>
  );
}
